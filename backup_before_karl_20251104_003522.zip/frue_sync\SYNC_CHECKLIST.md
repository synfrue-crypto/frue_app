﻿# Sync-Checkliste (tÃ¤glich)

[ ] flutter_ai_inbox/ gesichtet?
[ ] Alle Dateien mit Status-Label?
[ ] Manifest-Struktur geprÃ¼ft?
[ ] Safe-Mode beachtet (keine Auto-Builds)?
