
# süfrü Feinschliff Layout v3

- Kategorie-Chips in Markenfarbe
- Responsives Grid (1–5 Spalten)
- Grid-Karte mit Badge links, Name fett, Preis rechts in Markenfarbe
- Detailseite: kleineres Bild links, großer Preis rechts, fette Überschriften

Dateien:
- lib/brand/brand_theme.dart
- lib/widgets/responsive_grid.dart
- lib/widgets/badges.dart
- lib/widgets/product_card.dart
- lib/shop/shop_list_page.dart
- lib/shop/product_detail_page.dart
