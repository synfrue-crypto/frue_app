﻿# FRÃœ Â· Soft-Handshake: Flutter AI Ã— Rio (GPT-5)

Dieser Ordner koppelt die lokale Flutter AI (IDE) sicher mit Rio (GPT-5), ohne direkten Datenaustausch.
Alle Ãœbergaben laufen sichtbar Ã¼ber /frue_sync/.

Ordner:
- flutter_ai_inbox/   â†’ VorschlÃ¤ge von Flutter AI
- flutter_ai_outbox/  â†’ geprÃ¼fte Freigaben von Rio

Ablauf:
1. Flutter AI legt VorschlÃ¤ge in flutter_ai_inbox/
2. Du lÃ¤dst sie hier im Chat hoch â†’ Rio prÃ¼ft
3. Freigegebene Antworten liegen in flutter_ai_outbox/
