
import 'package:flutter/material.dart';
import 'cart_model.dart';
import 'product_utils.dart' show nameOf, unitOf, priceOf;

class CartPage extends StatelessWidget {
  final Map<String, Map<String, dynamic>>? productIndex;
  const CartPage({super.key, this.productIndex});

  Map<String, dynamic>? _lookup(String id) {
    if (productIndex == null) return null;
    return productIndex![id];
  }

  @override
  Widget build(BuildContext context) {
    final cart = CartProvider.of(context);
    final ids = cart.items.keys.toList();

    double lineTotal(String id, int units) {
      final p = _lookup(id);
      final step = (p?['qty_step'] is num) ? (p!['qty_step'] as num).toDouble() : ((p != null && unitOf(p).toLowerCase() == 'kg') ? 0.5 : 1.0);
      final qty = units * step;
      final price = (p != null ? (priceOf(p) ?? 0).toDouble() : 0.0);
      return qty * price;
    }

    final total = ids.fold<double>(0.0, (sum, id) => sum + lineTotal(id, cart.items[id]!));

    return Scaffold(
      appBar: AppBar(title: const Text('Warenkorb')),
      body: ids.isEmpty
          ? const Center(child: Text('Dein Warenkorb ist leer.'))
          : ListView.separated(
              itemCount: ids.length + 1,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, i) {
                if (i == ids.length) {
                  return Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Text('Summe', style: Theme.of(context).textTheme.titleMedium),
                        const Spacer(),
                        Text(total.toStringAsFixed(2) + ' €', style: Theme.of(context).textTheme.titleMedium),
                      ],
                    ),
                  );
                }
                final id = ids[i];
                final units = cart.items[id]!;
                final p = _lookup(id);
                final name = p != null ? nameOf(p) : id;
                final unit = p != null ? unitOf(p) : 'stk';
                final step = (p?['qty_step'] is num) ? (p!['qty_step'] as num).toDouble() : (unit.toLowerCase() == 'kg' ? 0.5 : 1.0);
                final qty = units * step;
                final lt = lineTotal(id, units);

                return ListTile(
                  title: Text(name),
                  subtitle: Text(qty.toStringAsFixed(qty.truncateToDouble()==qty?0:2) + ' ' + unit.toLowerCase()),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(icon: const Icon(Icons.remove_circle_outline), onPressed: units > 0 ? () => cart.remove(id) : null),
                      Text(units.toString()),
                      IconButton(icon: const Icon(Icons.add_circle_outline), onPressed: () => cart.add(id)),
                      const SizedBox(width: 12),
                      Text(lt.toStringAsFixed(2) + ' €'),
                    ],
                  ),
                );
              },
            ),
      bottomNavigationBar: ids.isEmpty ? null : SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: FilledButton(
            onPressed: () {
              // Weiter zur Entgegennahme (Selector)
              Navigator.pushNamed(context, '/fulfillment');
            },
            child: const Text('Entgegennahme wählen'),
          ),
        ),
      ),
    );
  }
}
