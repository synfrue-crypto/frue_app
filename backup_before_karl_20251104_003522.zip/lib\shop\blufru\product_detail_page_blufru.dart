// lib/shop/blufru/product_detail_page_blufru.dart
import 'package:flutter/material.dart';

/// Simple placeholder product detail for blüfrü (Im Aufbau).
class ProductDetailPageBlufru extends StatelessWidget {
  final String brand;
  final Map<String, dynamic> product;

  const ProductDetailPageBlufru({
    super.key,
    required this.brand,
    required this.product,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('blüfrü · Produkt')),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: const [
            Icon(Icons.construction, size: 64),
            SizedBox(height: 12),
            Text('Produktseite im Aufbau', style: TextStyle(fontSize: 18)),
          ],
        ),
      ),
    );
  }
}
