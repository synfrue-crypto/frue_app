import 'package:flutter/material.dart';
import 'shop_launcher.dart';

class BrandHomePage extends StatelessWidget {
  const BrandHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('frü – Shops')),
      body: ListView(
        children: [
          _tile(context, 'süfrü – Früchte', 'sufru'),
          _tile(context, 'grüfrü – Garten',  'grufru'),
          _tile(context, 'blüfrü – Blumen',  'blufru'),
        ],
      ),
    );
  }

  Widget _tile(BuildContext context, String title, String brand) {
    return ListTile(
      leading: CircleAvatar(child: Text(title.characters.first.toUpperCase())),
      title: Text(title),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => ShopLauncher()),
      ),
    );
  }
}
