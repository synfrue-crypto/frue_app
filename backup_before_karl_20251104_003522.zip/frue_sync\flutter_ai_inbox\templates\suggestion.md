﻿[WIP]
# Vorschlagstitel

## Kontext
- Datei(en):
- Problem:
- Ziel:

## Ã„nderung
- Kurzbeschreibung:
- Risiko:

## Tests
- Manuell:
- Analyzer:
