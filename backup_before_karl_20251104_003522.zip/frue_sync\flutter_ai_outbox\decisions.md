﻿# Decisions
## 2025-11-03 Â· Initialisierung
- Status: OK
- Kommentar: Struktur erfolgreich erstellt.
## 2025-11-03 · Integration Flutter AI (Karl)
- Status: ACTIVE
- Alias: Karl
- Rolle: Flutter-Techniker (Build, Analyzer, Hotfix)
- Sync-Ordner: /frue_sync/
- Kommunikation: Prompts & Dateien über Andi (mittels Rio)
