import 'package:flutter/material.dart';
import '../services/data_loader.dart';
import '../shop/sufru/shop_list_page_sufru.dart';

class ShopLauncher extends StatelessWidget {
  const ShopLauncher({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('frü · Shops')),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: DataLoader.loadCatalogSufru(),
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError || (snap.data ?? []).isEmpty) {
            return Center(
              child: Text('Katalog (süfrü) nicht gefunden.\n${snap.error ?? ''}'),
            );
          }
          final products = snap.data!;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              ListTile(
                leading: const Icon(Icons.local_grocery_store),
                title: const Text('süfrü öffnen'),
                subtitle: const Text('Startseite → Grid → Detail → Warenkorb'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ShopListPageSufru(products: products),
                  ),
                ),
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.eco_outlined),
                title: const Text('grüfrü'),
                subtitle: const Text('Im Aufbau – später aktivierbar'),
                trailing: const Icon(Icons.construction),
                onTap: () => ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('grüfrü: später aktivierbar')),
                ),
              ),
              ListTile(
                leading: const Icon(Icons.local_florist_outlined),
                title: const Text('blüfrü'),
                subtitle: const Text('Im Aufbau – später aktivierbar'),
                trailing: const Icon(Icons.construction),
                onTap: () => ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('blüfrü: später aktivierbar')),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
