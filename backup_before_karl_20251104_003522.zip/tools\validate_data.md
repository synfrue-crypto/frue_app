# Datenprüfung (Offline)
1. Prüfe JSON-Struktur mit https://jsonlint.com/
2. Alle Keys: name, id, price, unit
3. Keine Sonderzeichen in IDs.
4. fulfillment.csv / units_override.csv UTF-8 speichern.
