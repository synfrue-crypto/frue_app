package com.example.frue_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
