import 'package:flutter/material.dart';
import '../../theme/brand_theme.dart';
import '../../widgets/quantity_input.dart';
import '../../widgets/smart_image.dart';
import '../../cart/cart_provider.dart';

class ProductDetailPageSufru extends StatefulWidget {
  final String brand;
  final Map<String, dynamic> product;

  const ProductDetailPageSufru({super.key, required this.brand, required this.product});

  @override
  State<ProductDetailPageSufru> createState() => _ProductDetailPageState();
}

class _ProductDetailPageState extends State<ProductDetailPageSufru> {
  double qty = 1.0;

  @override
  Widget build(BuildContext context) {
    final brand = widget.brand;
    final color = BrandTheme.colorFor(brand);
    final priceStyle = BrandTheme.priceStyle(brand);

    final m = widget.product;
    final id = (m['id'] ?? '').toString();
    final name = (m['name'] ?? '').toString();
    final imgId = (m['asset_id'] ?? '').toString();
    final price = (m['price'] ?? 0).toDouble();
    final unit = (m['unit'] ?? '').toString();
    final shortDesc = (m['short_desc'] ?? '').toString();
    final longDesc = (m['long_desc'] ?? '').toString();
    final step = (m['qty_step'] ?? 1.0).toDouble();

    return Scaffold(
      appBar: AppBar(title: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          AspectRatio(
            aspectRatio: 1.6,
            child: SmartAssetImage([imgId], fit: BoxFit.cover, borderRadius: BorderRadius.circular(12)),
          ),
          const SizedBox(height: 12),
          Center(
            child: Text(name,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          ),
          const SizedBox(height: 6),
          Center(
            child: Text(
              '${price.toStringAsFixed(2)} € / $unit',
              style: priceStyle,
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              QuantityInput(
                value: qty,
                onChanged: (v) => setState(() => qty = v),
                step: step,
                unitLabel: unit.isEmpty ? null : unit,
              ),
              const Spacer(),
              FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: color),
                onPressed: () {
                  CartProvider.of(context).add(id, by: qty);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Zum Warenkorb hinzugefügt')),
                  );
                },
                icon: const Icon(Icons.add_shopping_cart),
                label: const Text('Jetzt bestellen'),
              ),
            ],
          ),
          const SizedBox(height: 16),
          if (shortDesc.isNotEmpty) Text(shortDesc),
          if (longDesc.isNotEmpty) ...[
            const SizedBox(height: 12),
            Text(longDesc),
          ],
        ],
      ),
    );
  }
}
