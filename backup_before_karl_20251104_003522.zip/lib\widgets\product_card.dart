import 'package:flutter/material.dart';
import '../theme/brand_theme.dart';
import 'smart_image.dart';
import '../cart/cart_provider.dart';

class ProductCard extends StatelessWidget {
  final Map<String, dynamic> product;
  final String brand;
  final VoidCallback onTap;

  const ProductCard({
    super.key,
    required this.product,
    required this.brand,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final color = BrandTheme.colorFor(brand);
    final priceStyle = BrandTheme.priceStyle(brand);

    final imgId = (product['asset_id'] ?? '').toString();
    final name = (product['name'] ?? '').toString();
    final price = (product['price'] ?? 0).toDouble();
    final unit = (product['unit'] ?? '').toString();
    final id = (product['id'] ?? '').toString();

    return InkWell(
      onTap: onTap,
      child: Card(
        clipBehavior: Clip.antiAlias,
        elevation: 1.5,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            AspectRatio(
              aspectRatio: 1.2,
              child: SmartAssetImage([imgId], fit: BoxFit.cover),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
              child: Text(
                name,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w600),
                textAlign: TextAlign.center,
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('${price.toStringAsFixed(2)} €/ $unit', style: priceStyle),
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    icon: Icon(Icons.add_shopping_cart, color: color),
                    onPressed: () => CartProvider.of(context).add(id),
                    tooltip: 'In den Warenkorb',
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
