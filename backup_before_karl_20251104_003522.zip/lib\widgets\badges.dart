
import 'package:flutter/material.dart';

/// Quality badge for Bio/Demeter (icon-only).
/// Default size is 28px (Variante A).
class QualityBadges extends StatelessWidget {
  final String? brandQuality;
  final double size;
  const QualityBadges({super.key, this.brandQuality, this.size = 28});

  @override
  Widget build(BuildContext context) {
    final q = (brandQuality ?? '').toLowerCase().trim();
    String? asset;
    if (q == 'bio') asset = 'assets/icons/bio.png';
    if (q == 'demeter') asset = 'assets/icons/demeter.png';
    if (asset == null) return const SizedBox.shrink();
    return Image.asset(asset, height: size, width: size, fit: BoxFit.contain);
  }
}
