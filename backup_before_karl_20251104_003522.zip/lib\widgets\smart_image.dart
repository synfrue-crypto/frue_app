import 'package:flutter/material.dart';

/// Übergibt eine Liste von Kandidaten (nur Asset-IDs ohne Endung, z.B. "SFRU-001-A0001")
/// oder komplette Pfade. Diese Funktion erzeugt valide Pfade und testet Endungen.
List<String> imageCandidates(String? assetIdOrPath) {
  if (assetIdOrPath == null || assetIdOrPath.trim().isEmpty) {
    return ['assets/data/frue/images/placeholder.jpg'];
  }
  final v = assetIdOrPath.trim();
  final looksLikePath = v.contains('/') && (v.endsWith('.jpg') || v.endsWith('.jpeg') || v.endsWith('.png'));
  if (looksLikePath) return [v];

  // Nur ID → baue Pfade
  final base = 'assets/data/frue/images/$v';
  return [
    '$base.jpg',
    '$base.jpeg',
    '$base.png',
  ];
}

class SmartAssetImage extends StatelessWidget {
  final List<String> sources;
  final BoxFit fit;
  final double? height;
  final double? width;
  final BorderRadius? borderRadius;

  SmartAssetImage(
    List<String?> candidates, {
    super.key,
    this.fit = BoxFit.cover,
    this.height,
    this.width,
    this.borderRadius,
  }) : sources = _flat(candidates);

  static List<String> _flat(List<String?> list) {
    final out = <String>[];
    for (final c in list) {
      out.addAll(imageCandidates(c));
    }
    // Fallback immer anhängen
    if (!out.contains('assets/data/frue/images/placeholder.jpg')) {
      out.add('assets/data/frue/images/placeholder.jpg');
    }
    return out;
  }

  @override
  Widget build(BuildContext context) {
    Widget img = Image.asset(
      sources.first,
      fit: fit,
      height: height,
      width: width,
      errorBuilder: (_, __, ___) {
        // Nächsten Kandidaten probieren
        final next = sources.length > 1 ? sources.sublist(1) : const <String>[];
        if (next.isEmpty) {
          return const Icon(Icons.image_not_supported_outlined, size: 32);
        }
        return SmartAssetImage(next, fit: fit, height: height, width: width, borderRadius: borderRadius);
      },
    );
    if (borderRadius != null) {
      return ClipRRect(borderRadius: borderRadius!, child: img);
    }
    return img;
  }
}
